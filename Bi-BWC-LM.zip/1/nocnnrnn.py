


# %%
from ner import load_and_preprocess_dataset, train_and_evaluate



# %% 得随时改
modelPath = "/home/featurize/work/1/distil-biobert"
tokenizerPath = "/home/featurize/work/1/distil-biobert"
datasetPath = f"/home/featurize/work/1/datasets/NER/BC5CDR-disease/"
logsPath = f"BC2GM-logs.txt"
# %%
import transformers as ts
tokenizer = ts.AutoTokenizer.from_pretrained(tokenizerPath)

# 数据预处理
tokenizedTrainDataset, tokenizedValDataset, tokenizedTestDataset, compute_metrics, label_names = load_and_preprocess_dataset(
    datasetPath=datasetPath,
    tokenizer=tokenizer
)



# %%
import torch.nn.functional as F
from torch import nn
from torch import Tensor



# %%
import torch
from torch import nn
from torchcrf import CRF
import numpy as np
import math

class CrossAttention(nn.Module):
    def __init__(self, bert_hidden_dim, char_hidden_dim):
        super(CrossAttention, self).__init__()
        self.bert_query = nn.Linear(bert_hidden_dim, bert_hidden_dim)
        self.char_query = nn.Linear(char_hidden_dim, bert_hidden_dim)
        self.attention = nn.Softmax(dim=1)
        self.dropout = nn.Dropout(p=0.1)

    def forward(self, bert_output, char_output):
        # 计算bert和char的query表示
        bert_query = self.bert_query(bert_output)
        char_query = self.char_query(char_output)

        # 计算交叉注意力得分
        cross_scores = torch.bmm(bert_query, char_query.transpose(1, 2))
        cross_scores = self.attention(cross_scores)

        # 计算char对bert的注意力加权值
        context = torch.bmm(cross_scores, char_output)

        # 融合bert和char的表示
        output = bert_output + context
        output = self.dropout(output)

        return output


class FocalLoss(nn.Module):
    '''Multi-class Focal loss implementation'''
    def __init__(self, gamma=2, weight=None,ignore_index=-100):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.weight = weight
        self.ignore_index=ignore_index

    def forward(self, input, target):
        """
        input: [N, C]
        target: [N, ]
        """
        logpt = F.log_softmax(input, dim=1)
        pt = torch.exp(logpt)
        logpt = (1-pt)**self.gamma * logpt
        loss = F.nll_loss(logpt, target, self.weight,ignore_index=self.ignore_index)
        return loss

class myModel(nn.Module):

    def __init__(self, n_class):
        super().__init__()

        self.n_class = n_class
        aft_att_size = 512

        self.Bert = ts.BertModel.from_pretrained(modelPath)
      
        # vocab_size = 200
#         char_embedding_dim = 768
        
       
#         self.char_embedding = CharCNNEmbedding(vocab_size, char_embedding_dim)
        self.cross_attn = CrossAttention(self.Bert.config.hidden_size, 768)  
        self.lstm = nn.LSTM(768,hidden_size=aft_att_size // 2, bidirectional=True, batch_first=True)
        
        self.attention = nn.MultiheadAttention(512, num_heads=4, batch_first=True)
        
     
        self.out = nn.Sequential(
            nn.Linear(aft_att_size, 128),
            nn.SiLU(),
            nn.Dropout(0.2),
            nn.Linear(128, n_class)
        )
        # self.crf = CRF(n_class, batch_first=True)
        self.loss_fct = nn.CrossEntropyLoss()
        self.FocalLoss= FocalLoss()

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            labels=None,
            input_lens=None, pos=None
    ):
        output1 = self.Bert(input_ids,attention_mask=attention_mask, )
        output2 = self.Bert(input_ids, attention_mask=attention_mask, )
        

        sequence_output1 = output1[0]
        sequence_output2 = output2[0]
       

        # 

        att_output1 = self.cross_attn(sequence_output1, sequence_output2)
      
    
       
        # # 是否要设置一个学习的权重参数
        output = att_output1+sequence_output1 #残差
        output, _ = self.lstm(output)
        
        attention_output = self.attention(output, output, output)     

        # MLP linear output projection
        logits = self.out(output)

        loss = 0

        if self.training:
            loss = self.loss_bk(logits, attention_mask, labels)
        else:
            logits = self.predict(logits, attention_mask)
            loss = self.loss_fct(logits.view(-1, self.n_class), labels.view(-1))
        return loss, logits

    def loss_bk(self, logits, attention_mask, labels):
     
        loss = self.loss_fct(logits.view(-1, self.n_class), labels.view(-1))+self.FocalLoss(logits.view(-1, self.n_class), labels.view(-1))
      
        return loss

    def predict(self, logits, attention_mask):
     
        return logits


# %%
model = myModel(len(label_names)).cuda()


model, valResults, testResults = train_and_evaluate(lr=5e-5,
                                                    batchsize=1,
                                                    epochs=1,
                                                    tokenizer=tokenizer,
                                                    tokenizedTrainDataset=tokenizedTrainDataset,
                                                    tokenizedValDataset=tokenizedValDataset,
                                                    tokenizedTestDataset=tokenizedTestDataset,
                                                    compute_metrics=compute_metrics,
                                                    label_names=label_names,
                                                    logsPath=logsPath,
                                                    trainingArgs=None,
                                                    model=model
                                                    )
total_params = sum(p.numel() for p in model.parameters())
print(f'{total_params:,} total parameters.')
total_trainable_params = sum(
    p.numel() for p in model.parameters() if p.requires_grad)
print(f'{total_trainable_params:,} training parameters.')
# %%
# BC5CDR-disease
# CharCNN + BioBERT

print(valResults, testResults)

# %%
# Best
print(valResults, testResults)

# %%
# test of MHSA

import torch
import torch.nn as nn

batch_size = 16
seq_len = 10
embedding_dim = 64
num_heads = 4

# Create input tensors
query = torch.randn(batch_size, seq_len, embedding_dim)
key = torch.randn(batch_size, seq_len, embedding_dim)
value = torch.randn(batch_size, seq_len, embedding_dim)

# Define the Multihead Attention layer
attention = nn.MultiheadAttention(embed_dim=embedding_dim, num_heads=num_heads)

# Apply the attention mechanism
output, _ = attention(query, key, value)

# Print the output shape
print(output.shape)










